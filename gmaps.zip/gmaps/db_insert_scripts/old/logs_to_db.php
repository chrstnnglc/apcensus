<?php
	$connect = mysqli_connect("localhost","root","");
	if(!$connect){
		die('Cant connect: '. mysqli_error($connect));
	}

	$set_db = mysqli_select_db($connect,"gmaps");
	if(!$set_db){
		die('Cant use db: '. mysqli_error($connect));
	}
	
	$myfile = fopen("../teachersvill/log-24/parsed_bflog2.txt", "r") or die("Unable to open file!");
	while(!feof($myfile)) {
		$line = fgets($myfile);
		$array = explode("=",$line);
		$ap_mac = trim($array[0]);
		$coord = explode(",",$array[1]);
		$lat = trim($coord[0]);
		$lng = trim($coord[1]);
		$rssi = trim($array[2]);
		$toparse = explode("|",$array[3]);
		$channel = trim($toparse[0]);
		$ssid = trim($toparse[1]);
		echo $ap_mac ." with coordinates ". $lat ." and ". $lng .", RSSI is: ". $rssi .",Ch: ". $channel .",SSID: ". $ssid ."<br>";
		$query = "INSERT INTO aps (ssid,mac,channel,lat,lng,rssi,label) VALUES ('$ssid','$ap_mac','$channel','$lat','$lng','$rssi','rpi')";
		$result = mysqli_query($connect,$query);
		if (!$result) {
			die('Invalid query: ' . mysqli_error($connect));
		}
	}
	fclose($myfile);
?>
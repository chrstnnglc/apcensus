<?php
	$connect = mysqli_connect("localhost","root","");
	if(!$connect){
		die('Cant connect: '. mysqli_error($connect));
	}

	$set_db = mysqli_select_db($connect,"gmaps");
	if(!$set_db){
		die('Cant use db: '. mysqli_error($connect));
	}
	
	$myfile = fopen("tve_confident.txt", "r") or die("Unable to open file!");
	while(!feof($myfile)) {
		$line = fgets($myfile);
		$array = explode("|",$line);
		$gps_time = trim($array[0]);
		$mac = trim($array[2]);
		$ssid = trim($array[3]);
		$enc = trim($array[4]);
		$rssi = trim($array[5]);
		$ch = trim($array[6]);
		$manuf = trim($array[7]);
		$ap_type = trim($array[8]);
		$lat = trim($array[9]);
		$lng = trim($array[10]);
		echo "GPS Time: ". $gps_time ." | Mac: ". $mac ." | SSID: ". $ssid ." | Enc: ". $enc ." | RSSI: ". $rssi ." | CH: ". $ch ." | Manuf: ". $manuf ." | Type: ". $ap_type ." | Lat: ". $lat ." | Lng: ". $lng;
		$query = "INSERT INTO ap_confident (gps_time,mac,ssid,enc,rssi,ch,manuf,ap_type,lat,lng,label,loc,gather_type) 
				VALUES ('$gps_time', '$mac', '$ssid', '$enc', '$rssi', '$ch', '$manuf', '$ap_type', '$lat', '$lng','rpi','tve','trike')";
		$result = mysqli_query($connect,$query);
		if (!$result) {
			die('Invalid query: ' . mysqli_error($connect));
		}
	}
	fclose($myfile);
?>
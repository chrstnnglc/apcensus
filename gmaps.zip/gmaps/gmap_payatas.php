<!DOCTYPE html >
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <title>AP Census Payatas</title>
	<link rel="stylesheet" href="gmaps.css">
  </head>

  <body>
    <div id="map"></div>
	
	<div id="legend_cont">
		<h2>Legend</h2>
		<div id="aps_legend">
			<p> <img src="rpc2_marker.png"> &nbsp RasPi detected APs </p>
			<p> <img src="w_marker.png"> &nbsp WiGLE detected APs </p>
			<p> <img src="ws_marker.png"> &nbsp WiGLE Database APs </p>
		</div>
		<h3> Grid Colors </h3>
		<table id="grid_legend_table_ap">
			<tr>
				<td><div class="grid_legend most_ap"></div></td>
				<td>More than 20 APs</td>
			</tr>
			<tr>
				<td><div class="grid_legend more_ap"></div></td>
				<td>15 to 20 APs</td>
			</tr>
			<tr>
				<td><div class="grid_legend less_ap"></div></td>
				<td>10 to 15 APs</td>
			</tr>
			<tr>
				<td><div class="grid_legend lesser_ap"></div></td>
				<td>5 to 10 APs</td>
			</tr>
			<tr>
				<td><div class="grid_legend least_ap"></div></td>
				<td>0 to 5 APs</td>
			</tr>
			<tr>
				<td><div class="grid_legend none"></div></td>
				<td>No data</td>
			</tr>
		</table>

		<table id="grid_legend_table_time">
			<tr>
				<td><div class="grid_legend most_time"></div></td>
				<td>More than 60 sec</td>
			</tr>
			<tr>
				<td><div class="grid_legend more_time"></div></td>
				<td>40 to 60 sec</td>
			</tr>
			<tr>
				<td><div class="grid_legend lesser_time"></div></td>
				<td>20 to 40 sec</td>
			</tr>
			<tr>
				<td><div class="grid_legend least_time"></div></td>
				<td>0 to 20 sec</td>
			</tr>
			<tr>
				<td><div class="grid_legend none"></div></td>
				<td>No data</td>
			</tr>
		</table>
		
		<table id="grid_legend_table_speed">
			<tr>
				<td><div class="grid_legend most_speed"></div></td>
				<td>More than 30 km/hr</td>
			</tr>
			<tr>
				<td><div class="grid_legend more_speed"></div></td>
				<td>20 to 30 km/hr</td>
			</tr>
			<tr>
				<td><div class="grid_legend lesser_speed"></div></td>
				<td>10 to 20 km/hr</td>
			</tr>
			<tr>
				<td><div class="grid_legend least_speed"></div></td>
				<td>0 to 10 km/hr</td>
			</tr>
			<tr>
				<td><div class="grid_legend none"></div></td>
				<td>No data</td>
			</tr>
		</table>
	</div>
	
	<div id="info_cont">
		<h2> RPi APs: <span id="rpi_ap"></span> APs</h2> 
		<h2> Density: <span id="density"></span> APs/box</h2> 
	</div>
	
	<div id="date_cont">
		<h2>Trips</h2>
		<table>
			<tr>
				<td><input id="mar14" name="trip" value ="03-14" type="checkbox" checked onchange="toggleTrips()"/></td>
				<td><b>03/14</b></td>
			</tr>
			<tr>
				<td><input id="mar22" name="trip" value ="03-22" type="checkbox" checked onchange="toggleTrips()"/></td>
				<td><b>03/22</b></td>
			</tr>
			<tr>
				<td><input id="apr2" name="trip" value ="04-02" type="checkbox" checked onchange="toggleTrips()"/></td>
				<td><b>04/02</b></td>
			</tr>
			<tr>
				<td><input id="apr3" name="trip" value ="04-03" type="checkbox" checked onchange="toggleTrips()"/></td>
				<td><b>04/03</b></td>
			</tr>
			<tr>
				<td><input id="apr5" name="trip" value ="04-05" type="checkbox" checked onchange="toggleTrips()"/></td>
				<td><b>04/05</b></td>
			</tr>
			<tr>
				<td><input id="apr10" name="trip" value ="04-10" type="checkbox" checked onchange="toggleTrips()"/></td>
				<td><b>04/10</b></td>
			</tr>
			<tr>
				<td><input id="apr13" name="trip" value ="04-13" type="checkbox" checked onchange="toggleTrips()"/></td>
				<td><b>04/13</b></td>
			</tr>
		</table>
	</div>
	
	<div id="selection_buttons">
		<input onclick="toggleWS()" type="button" value="Wigle Site" id="ws_button" class="buttons active">
		<input onclick="toggleRP()" type="button" value="RasPi" id="rp_button" class="buttons active">
		<input onclick="toggleW()" type="button" value="Wigle" id="w_button" class="buttons active">
		<input onclick="toggleTime()" type="button" value="Time Spent" id="time_button" class="buttons inactive">
		<input onclick="toggleSpeed()" type="button" value="Speed" id="speed_button" class="buttons inactive">
		<input onclick="toggleConfident()" type="button" value="Confident" id="conf_button" class="buttons inactive">
	</div>

	
<script src="js_scripts/init_vars.js"></script>
<script src="js_scripts/util_funcs.js"></script>
<script src="js_scripts/count_funcs.js"></script>
<script src="js_scripts/redraw_funcs.js"></script>
<script src="js_scripts/toggle_funcs.js"></script>
<script>
function gridMap() { 
	map = new google.maps.Map(document.getElementById('map'), 
		{ 
			zoom: 15,
			center: {lat: 14.704041, lng: 121.096697},
			mapTypeId: 'terrain',
			zoomControl: false
		}
	);
	//initialize infoWindow
	var infoWindow = new google.maps.InfoWindow;
	
	downloadUrl('fetch_payatas_db.php', function(data) {
		var xml = data.responseXML;
		var ap_list = xml.documentElement.getElementsByTagName('ap');
		//read elements of XML output
		Array.prototype.forEach.call(ap_list, function(ap) {
			var id = ap.getAttribute('id');
			var ssid = ap.getAttribute('ssid');
			var mac = ap.getAttribute('mac');
			var channel = ap.getAttribute('channel');
			var label = ap.getAttribute('label');
			var date = ap.getAttribute('gps_time');
			var lat = parseFloat(ap.getAttribute('lat'));
			var lng = parseFloat(ap.getAttribute('lng'));
			
			var point = new google.maps.LatLng(lat,lng);

			//set the content of the infoWindow
			var infowincontent = document.createElement('div');
			var strong = document.createElement('strong');
			strong.textContent = ssid
			infowincontent.appendChild(strong);
			infowincontent.appendChild(document.createElement('br'));
	  
			mac = "MAC: " + mac;
			channel = "Ch: " + channel;
			var text = document.createElement('text');
			text.textContent = mac
			infowincontent.appendChild(text);
			infowincontent.appendChild(document.createElement('br'));
			var text = document.createElement('text');
			text.textContent = channel
			infowincontent.appendChild(text);
			
			
			//set color of legend
			if (label == "rpi"){
				icon = 'rpc2_marker.png'
			}
			else if (label == "wigle"){
				icon = 'w_marker.png'
			}
			else if (label == "wiglesite"){
				icon = 'ws_marker.png'
			}
			
			//create marker
			var marker = new google.maps.Marker({
				map: map,
				position: point,
				icon: icon
			});
			
			//create marker info
			var markerinf = {
				mac: mac,
				date: date,
				lat: lat,
				lng: lng,
				label: label
			}
			
			//assign corresponding markers to array
			if (label == "rpi"){
				rp_markers.push(marker)
				toMarkArr.push(marker)
				RPmarkerinfArr.push(markerinf)
			}
			else if (label == "wigle"){
				w_markers.push(marker)
				WmarkerinfArr.push(markerinf)
			}
			else if (label == "wiglesite"){
				ws_markers.push(marker)
				WSmarkerinfArr.push(markerinf)
			}
			
			//show the info on mouse hover
			marker.addListener('mouseover', function() {
				infoWindow.setContent(infowincontent);
				infoWindow.open(map, marker);
			});
	  
			//hide info when mouse leaves the marker
			marker.addListener('mouseout', function() {
				infoWindow.setContent(infowincontent);
				infoWindow.close(map, marker);
			});
		});
		
		//get the confident AP readings
		var conf_list = xml.documentElement.getElementsByTagName('conf_ap');
		Array.prototype.forEach.call(conf_list, function(ap) {
			var id = ap.getAttribute('id');
			var ssid = ap.getAttribute('ssid');
			var mac = ap.getAttribute('mac');
			var channel = ap.getAttribute('channel');
			var label = ap.getAttribute('label');
			var date = ap.getAttribute('gps_time');
			var lat = parseFloat(ap.getAttribute('lat'));
			var lng = parseFloat(ap.getAttribute('lng'));
			
			var point = new google.maps.LatLng(lat,lng);

			//set the content of the infoWindow
			var infowincontent = document.createElement('div');
			var strong = document.createElement('strong');
			strong.textContent = ssid
			infowincontent.appendChild(strong);
			infowincontent.appendChild(document.createElement('br'));
	  
			mac = "MAC: " + mac;
			channel = "Ch: " + channel;
			var text = document.createElement('text');
			text.textContent = mac
			infowincontent.appendChild(text);
			infowincontent.appendChild(document.createElement('br'));
			var text = document.createElement('text');
			text.textContent = channel
			infowincontent.appendChild(text);
			
			icon = 'rpc2_marker.png'	//set icon just like the rpi
			
			//create marker
			var marker = new google.maps.Marker({
				map: map,
				position: point,
				icon: icon
			});
			
			//create marker info
			var markerinf = {
				mac: mac,
				date: date,
				lat: lat,
				lng: lng,
				label: label
			}
			
			c_markers.push(marker)
			CmarkerinfArr.push(markerinf)
			
			//show the info on mouse hover
			marker.addListener('mouseover', function() {
				infoWindow.setContent(infowincontent);
				infoWindow.open(map, marker);
			});
	  
			//hide info when mouse leaves the marker
			marker.addListener('mouseout', function() {
				infoWindow.setContent(infowincontent);
				infoWindow.close(map, marker);
			});
			
		});
		
		//get the gps readings
		var gps_list = xml.documentElement.getElementsByTagName('gps');
		Array.prototype.forEach.call(gps_list, function(gps) {
			var datextime = gps.getAttribute('time');
			var gps_time = new Date(datextime);
			var id = gps.getAttribute('id');
			lat = parseFloat(gps.getAttribute('lat'));
			lng = parseFloat(gps.getAttribute('lng'));
			
		
			var gpsinf = {
				time: gps_time,
				lat: lat,
				lng: lng
			}
			GPSmarkerinfArr.push(gpsinf)
			
		});
		var north = 14.711184;//14.705009; use j < 17 and i < 19
		var south = LatCoordDistance(north,50);
		var west = 121.088027;//121.087869;
		var east = LngCoordDistance(north,west,50);
		var rectangle;
		var unique_macs = [];		//this will contain RPi unique macs. We will eliminate multiple counting of APs that lie in boundaries
		total_count = 0;
		for(j=0; j < 31; j++){
			if(j!=0){
				north = south;
				south = LatCoordDistance(north,50);//south = +((north - 0.000453).toFixed(6));
				west = 121.088027;//121.087869;	//set the value of this equal to the initial west bound
				var east = LngCoordDistance(north,west,50);
			}
			for(i=0; i < 20; i++){
				if(i!=0){
					west = east;
					east = LngCoordDistance(north,west,50); //east = +((west + 0.000453).toFixed(6));
				} 
				rectangle = new google.maps.Rectangle({ 
					strokeColor: '#000000', 
					strokeOpacity: 0.8, 
					strokeWeight: 1, 
					fillColor: '#000000', 
					fillOpacity: 0.0,  
					map: map, 
					bounds: { 
						north: north, 
						south: south, 
						east: east, 
						west: west  
					} 
				});
				
				//loop through all of our points and check whether it is inside this grid/rectangle being drawn 
				rp_count = 0;
				w_count = 0;
				ws_count = 0;
				rect_count = 0;
				c_count = 0;
				for(x = 0; x < RPmarkerinfArr.length; x++){
					var point = new google.maps.LatLng(RPmarkerinfArr[x].lat, RPmarkerinfArr[x].lng);
					if(rectangle.getBounds().contains(point)){
						if(unique_macs.length == 0){	//this should only happen once.
							unique_macs.push(RPmarkerinfArr[x].mac);
							rp_count++;
						}
						if(unique_macs.indexOf(RPmarkerinfArr[x].mac) == -1){
							unique_macs.push(RPmarkerinfArr[x].mac);
							rp_count++;
						}
					}
				}
				for(x = 0; x < WmarkerinfArr.length; x++){
					var point = new google.maps.LatLng(WmarkerinfArr[x].lat, WmarkerinfArr[x].lng);
					if(rectangle.getBounds().contains(point)){
						w_count++;
					}
				}
				for(x = 0; x < WSmarkerinfArr.length; x++){
					var point = new google.maps.LatLng(WSmarkerinfArr[x].lat, WSmarkerinfArr[x].lng);
					if(rectangle.getBounds().contains(point)){
						ws_count++;
					}
				}
				for(x = 0; x < CmarkerinfArr.length; x++){
					var point = new google.maps.LatLng(CmarkerinfArr[x].lat, CmarkerinfArr[x].lng);
					if(rectangle.getBounds().contains(point)){
						c_count++;
					}
				}
				rect_count = rp_count + w_count + ws_count;
				if (rect_count != 0){
					if(rect_count > 20){
						color = "#FF0000";
					}
					else if(rect_count > 15 && rect_count <= 20){
						color = "#FA8072";
					}
					else if(rect_count > 10 && rect_count <= 15){
						color = "#F88379";
					}
					else if(rect_count > 5 && rect_count <= 10){
						color = "#FF91A4";
					}
					else if(rect_count > 0 && rect_count <= 5){
						color = "#FFC0CB";
					}
					rectangle.setOptions({
						fillColor: color,
						fillOpacity: 0.9
					});
				}
				rectArr.push(rectangle);
				total_count = total_count + rect_count;
				
				var rectinf = {
					rp_count: rp_count,
					w_count: w_count,
					ws_count: ws_count,
					c_count: c_count,
					count: String(rect_count),
					time: 0,
					speed: 0,
					traversal: 0
				}
				RectinfArr.push(rectinf)
			}
		}
		console.log("Total Count of all APs: " + total_count);
		var rpTotalCount = 0;
		for(i = 0; i < RectinfArr.length; i++){
			rpTotalCount = rpTotalCount + RectinfArr[i].rp_count
		}
		console.log("Total RPi Count: " + rpTotalCount);
		document.getElementById("rpi_ap").innerHTML=rpTotalCount;
		console.log("Number of Boxes: " + rectArr.length)
		
		//count how many seconds did we stay inside the rectangle
		for(i = 0; i < rectArr.length; i++){
			first_time = 0
			for(x = 0; x < GPSmarkerinfArr.length; x++){
				var point = new google.maps.LatLng(GPSmarkerinfArr[x].lat, GPSmarkerinfArr[x].lng);
				if(rectArr[i].getBounds().contains(point)){
					if(first_time == 0){
						start = GPSmarkerinfArr[x].time;
						first_time = 1;
						has_readingsCount ++;
						start_point = point;
					}
				}
				else{
					//if there was a previous gps reading in this box
					if(first_time == 1){
						time_spent = (GPSmarkerinfArr[x-1].time - start)/1000;
						RectinfArr[i].time += time_spent;
						first_time = 0;
						end_point = new google.maps.LatLng(GPSmarkerinfArr[x-1].lat, GPSmarkerinfArr[x-1].lng);
						
						//compute for the speed
						var distance = google.maps.geometry.spherical.computeDistanceBetween(start_point, end_point);	//this returns distance in meters
						//there are cases where time_spent = 0. we avoid this so we wont have a speed = infinity
						if (time_spent != 0){
							speed = (distance / time_spent) * 3.6;	//we multiply by 3.6 to convert from m/s to km/h
							RectinfArr[i].speed += speed;
							RectinfArr[i].traversal++;
						}
					}
				}
			}
		}
		/*
		console.log(parseInt((GPSmarkerinfArr[10].time - GPSmarkerinfArr[0].time)/1000));
		var start_point = new google.maps.LatLng(GPSmarkerinfArr[0].lat, GPSmarkerinfArr[0].lng);
		var end_point = new google.maps.LatLng(GPSmarkerinfArr[10].lat, GPSmarkerinfArr[10].lng);
		console.log(google.maps.geometry.spherical.computeDistanceBetween(start_point, end_point));*/
		
		//add event listners for each rectangle and get the count in that rectangle
		for(i = 0; i < rectArr.length; i++){
			google.maps.event.addListener(rectArr[i],'click', function(event) {
				for(j = 0; j < rectArr.length; j++){
					if(rectArr[j].getBounds().contains(event.latLng)){
						rect_count = RectinfArr[j].count;
						rect_time = RectinfArr[j].time;
						if (RectinfArr[j].traversal != 0){
							rect_avgspeed = (RectinfArr[j].speed / RectinfArr[j].traversal).toFixed(4);	//we compute for the average speed in the boxes
						}
						else{
							rect_avgspeed = 0
						}
						trav = RectinfArr[j].traversal;
					}
				}
				infoWindow.setContent("# of APs: <b>" + String(rect_count) + "</b> <br> Time Spent: <b>" + String(rect_time) + " seconds </b> <br> Avg. Speed: <b>" + String(rect_avgspeed) + " km/hr </b> <br> # of Traversal: <b>" + String(trav) + "</b>")
				infoWindow.setPosition(event.latLng);
				infoWindow.open(map);
			}); 
		}
		var traversed_boxes = 0;
		for(i = 0; i < RectinfArr.length; i++){
			if(RectinfArr[i].traversal != 0){
				traversed_boxes ++;
			}
		}
		console.log("Traversed Boxes: " + String(traversed_boxes));
		var densitynum = rpTotalCount/traversed_boxes	//we compute density (RPi captured APs/ number of boxes)
		document.getElementById("density").innerHTML=densitynum.toFixed(3);
	});
	
	//add the list of legend, and toggle buttons in the map
	map.controls[google.maps.ControlPosition.LEFT_TOP].push(document.getElementById('info_cont'));
	map.controls[google.maps.ControlPosition.LEFT_TOP].push(document.getElementById('legend_cont'));
	map.controls[google.maps.ControlPosition.RIGHT_TOP].push(document.getElementById('date_cont'));
	map.controls[google.maps.ControlPosition.BOTTOM_CENTER].push(document.getElementById('selection_buttons'));
}

function downloadUrl(url, callback) {
	var request = window.ActiveXObject ?
		new ActiveXObject('Microsoft.XMLHTTP') :
		new XMLHttpRequest;

	request.onreadystatechange = function() {
		if (request.readyState == 4) {
			request.onreadystatechange = doNothing;
			callback(request, request.status);
		}
	};

	request.open('GET', url, true);
	request.send(null);
}

function doNothing() {}
</script>
    <script
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCz_xDT4_D32UQ__xr91UT-_P9a7bcOG2Q&callback=gridMap&libraries=geometry">
    </script>
  </body>
</html>
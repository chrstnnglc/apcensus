function countRectAP(){
	total_count = 0;
	for(i = 0; i < rectArr.length; i++){
		//loop through all of our points and check whether it is inside this grid/rectangle being drawn
		rect_count = 0;
		if(document.getElementById("rp_button").classList.contains("active")){
			rect_count = rect_count + RectinfArr[i].rp_count
		}
		if(document.getElementById("w_button").classList.contains("active")){
			rect_count = rect_count + RectinfArr[i].w_count
		}
		if(document.getElementById("ws_button").classList.contains("active")){
			rect_count = rect_count + RectinfArr[i].ws_count
		}
		if(rect_count != 0){
			if(rect_count > 20){
				color = "#FF0000";
			}
			else if(rect_count > 15 && rect_count <= 20){
				color = "#FA8072";
			}
			else if(rect_count > 10 && rect_count <= 15){
				color = "#F88379";
			}
			else if(rect_count > 5 && rect_count <= 10){
				color = "#FF91A4";
			}
			else if(rect_count > 0 && rect_count <= 5){
				color = "#FFC0CB";
			}
			rectArr[i].setOptions({
				fillColor: color,
				fillOpacity: 0.9
			});
		}
		else if (rect_count == 0){
			rectArr[i].setOptions({
				fillColor: "#000000",  //any color will do as long as transparent
				fillOpacity: 0.0
			});
		}
		RectinfArr[i].count = String(rect_count);
		total_count = total_count + rect_count
	}
	//console.log("Total Count: " + total_count)
}

function countRectTime(){
	for(i = 0; i < rectArr.length; i++){
		rect_time = RectinfArr[i].time
		if(rect_time != 0){
			//    !!!!!!!     change the values to higher times next time     !!!!!!!!!!!!!!
			if(rect_time > 60){
				color = "#A98600"
			}
			else if(rect_time > 40 && rect_time <= 60){
				color = "#E0B300"
			}
			else if(rect_time > 20 && rect_time <= 40){
				color = "#E9D700"
			}
			else if(rect_time > 0 && rect_time <= 20){
				color = "#FFF9AE"
			}
			rectArr[i].setOptions({
				fillColor: color,
				fillOpacity: 0.9
			});
		}
		else if(rect_time == 0){
			rectArr[i].setOptions({
				fillColor: "#000000",  //any color will do as long as transparent
				fillOpacity: 0.0
			});
		}
	}
}

function countRectSpeed(){
	for(i = 0; i < rectArr.length; i++){
		if (RectinfArr[i].traversal != 0){
			rect_speed = (RectinfArr[i].speed / RectinfArr[i].traversal).toFixed(4);	//we compute for the average speed in the boxes
			console.log(rect_speed)
			if(rect_speed > 30){
				color = "#163317"
			}
			else if(rect_speed > 20 && rect_speed <= 30){
				color = "#214D22"
			}
			else if(rect_speed > 10 && rect_speed <= 20){
				color = "#47A64A"
			}
			else if(rect_speed > 0 && rect_speed <= 10){
				color = "#80FF84"
			}
			rectArr[i].setOptions({
				fillColor: color,
				fillOpacity: 0.9
			});
		}
		else{
			rectArr[i].setOptions({
				fillColor: "#000000",  //any color will do as long as transparent
				fillOpacity: 0.0
			});
		}
	}
}
function toggleRP() {
	if(document.getElementById("rp_button").classList.contains("active")){
		document.getElementById("rp_button").classList.remove("active");
		document.getElementById("rp_button").classList.add("inactive");
		RPsetMap(null);
	}
	else if(document.getElementById("rp_button").classList.contains("inactive")){
		document.getElementById("rp_button").classList.remove("inactive");
		document.getElementById("rp_button").classList.add("active");
		RPsetMap(map);
		if(document.getElementById("conf_button").classList.contains("active")){
			document.getElementById("conf_button").classList.remove("active");
			document.getElementById("conf_button").classList.add("inactive");
			CsetMap(null);
		}
	}
	
	//set Time Spent button to inactive if it is active
	if(document.getElementById("time_button").classList.contains("active")){
		document.getElementById("time_button").classList.remove("active");
		document.getElementById("time_button").classList.add("inactive");
	}
	//set Speed button to inactive if it is active
	if(document.getElementById("speed_button").classList.contains("active")){
		document.getElementById("speed_button").classList.remove("active");
		document.getElementById("speed_button").classList.add("inactive");
	}
	
	redrawRectangle(null);
	countRectAP();
	redrawRectangle(map);
	document.getElementById("grid_legend_table_time").style.display = "none";
	document.getElementById("grid_legend_table_speed").style.display = "none";
	document.getElementById("grid_legend_table_ap").style.display = "block";
}

function toggleW() {
	if(document.getElementById("w_button").classList.contains("active")){
		document.getElementById("w_button").classList.remove("active");
		document.getElementById("w_button").classList.add("inactive");
		WsetMap(null);
	}
	else if(document.getElementById("w_button").classList.contains("inactive")){
		document.getElementById("w_button").classList.remove("inactive");
		document.getElementById("w_button").classList.add("active");
		WsetMap(map);
	}
	
	//set Time Spent button to inactive if it is active
	if(document.getElementById("time_button").classList.contains("active")){
		document.getElementById("time_button").classList.remove("active");
		document.getElementById("time_button").classList.add("inactive");
	}
	//set Speed button to inactive if it is active
	if(document.getElementById("speed_button").classList.contains("active")){
		document.getElementById("speed_button").classList.remove("active");
		document.getElementById("speed_button").classList.add("inactive");
	}
	
	redrawRectangle(null);
	countRectAP();
	redrawRectangle(map);
	document.getElementById("grid_legend_table_time").style.display = "none";
	document.getElementById("grid_legend_table_speed").style.display = "none";
	document.getElementById("grid_legend_table_ap").style.display = "block";
}

function toggleWS() {
	if(document.getElementById("ws_button").classList.contains("active")){
		document.getElementById("ws_button").classList.remove("active");
		document.getElementById("ws_button").classList.add("inactive");
		WSsetMap(null);
	}
	else if(document.getElementById("ws_button").classList.contains("inactive")){
		document.getElementById("ws_button").classList.remove("inactive");
		document.getElementById("ws_button").classList.add("active");
		WSsetMap(map);
	}
	
	//set Time Spent button to inactive if it is active
	if(document.getElementById("time_button").classList.contains("active")){
		document.getElementById("time_button").classList.remove("active");
		document.getElementById("time_button").classList.add("inactive");
	}
	//set Speed button to inactive if it is active
	if(document.getElementById("speed_button").classList.contains("active")){
		document.getElementById("speed_button").classList.remove("active");
		document.getElementById("speed_button").classList.add("inactive");
	}
	
	redrawRectangle(null);
	countRectAP();
	redrawRectangle(map);
	document.getElementById("grid_legend_table_time").style.display = "none";
	document.getElementById("grid_legend_table_speed").style.display = "none";
	document.getElementById("grid_legend_table_ap").style.display = "block";
}

function toggleTime(){
	if(document.getElementById("time_button").classList.contains("active")){
		document.getElementById("time_button").classList.remove("active");
		document.getElementById("time_button").classList.add("inactive");
		redrawRectangle(null);
		countRectAP();
		redrawRectangle(map);
		document.getElementById("grid_legend_table_time").style.display = "none";
		document.getElementById("grid_legend_table_speed").style.display = "none";
		document.getElementById("grid_legend_table_ap").style.display = "block";
	}
	else if(document.getElementById("time_button").classList.contains("inactive")){
		document.getElementById("time_button").classList.remove("inactive");
		document.getElementById("time_button").classList.add("active");
		redrawRectangle(null);
		countRectTime();
		redrawRectangle(map);
		document.getElementById("grid_legend_table_time").style.display = "block";
		document.getElementById("grid_legend_table_speed").style.display = "none";
		document.getElementById("grid_legend_table_ap").style.display = "none";
	}
	
	//set Speed button to inactive if it is active
	if(document.getElementById("speed_button").classList.contains("active")){
		document.getElementById("speed_button").classList.remove("active");
		document.getElementById("speed_button").classList.add("inactive");
	}
}

function toggleSpeed(){
	if(document.getElementById("speed_button").classList.contains("active")){
		document.getElementById("speed_button").classList.remove("active");
		document.getElementById("speed_button").classList.add("inactive");
		redrawRectangle(null);
		countRectAP();
		redrawRectangle(map);
		document.getElementById("grid_legend_table_time").style.display = "none";
		document.getElementById("grid_legend_table_speed").style.display = "none";
		document.getElementById("grid_legend_table_ap").style.display = "block";
		
	}
	else if(document.getElementById("speed_button").classList.contains("inactive")){
		document.getElementById("speed_button").classList.remove("inactive");
		document.getElementById("speed_button").classList.add("active");
		redrawRectangle(null);
		countRectSpeed();
		redrawRectangle(map);
		document.getElementById("grid_legend_table_time").style.display = "none";
		document.getElementById("grid_legend_table_speed").style.display = "block";
		document.getElementById("grid_legend_table_ap").style.display = "none";
	}
	
	//set Time Spent button to inactive if it is active
	if(document.getElementById("time_button").classList.contains("active")){
		document.getElementById("time_button").classList.remove("active");
		document.getElementById("time_button").classList.add("inactive");
	}
}

function toggleConfident(){
	if(document.getElementById("conf_button").classList.contains("active")){
		document.getElementById("conf_button").classList.remove("active");
		document.getElementById("conf_button").classList.add("inactive");
		CsetMap(null);
		if(document.getElementById("rp_button").classList.contains("inactive")){
			document.getElementById("rp_button").classList.remove("inactive");
			document.getElementById("rp_button").classList.add("active");
			RPsetMap(map);
		}
	}
	else if(document.getElementById("conf_button").classList.contains("inactive")){
		document.getElementById("conf_button").classList.remove("inactive");
		document.getElementById("conf_button").classList.add("active");
		CsetMap(map);
		if(document.getElementById("rp_button").classList.contains("active")){
			document.getElementById("rp_button").classList.remove("active");
			document.getElementById("rp_button").classList.add("inactive");
			RPsetMap(null);
		}
	}
	
	//set Time Spent button to inactive if it is active
	if(document.getElementById("time_button").classList.contains("active")){
		document.getElementById("time_button").classList.remove("active");
		document.getElementById("time_button").classList.add("inactive");
	}
	//set Speed button to inactive if it is active
	if(document.getElementById("speed_button").classList.contains("active")){
		document.getElementById("speed_button").classList.remove("active");
		document.getElementById("speed_button").classList.add("inactive");
	}
	
	redrawRectangle(null);
	countRectAP();
	redrawRectangle(map);
	document.getElementById("grid_legend_table_time").style.display = "none";
	document.getElementById("grid_legend_table_speed").style.display = "none";
	document.getElementById("grid_legend_table_ap").style.display = "block";
}

function toggleTrips(){
	tripsArr = [];
	var chkArr = document.getElementsByName("trip");
	for (i=0; i<chkArr.length;i++){
		if(chkArr[i].checked==false){
			tripsArr.push(chkArr[i].value)
		}
	}
	RPsetMap(null);
	toMarkArr = [];
	//dont include markers with dates equal to tripsArr in toMarkArr
	for (i=0; i<RPmarkerinfArr.length;i++){
		notinclude = 0;
		for (j=0; j<tripsArr.length;j++){
			if(RPmarkerinfArr[i].date.indexOf(tripsArr[j]) != -1){
				notinclude = 1;
				break;
			}
		}
		if(notinclude==0){
			toMarkArr.push(rp_markers[i])
		}
	}
	toMarksetMap(map);
}
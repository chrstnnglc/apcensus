//Haversine function
function LatCoordDistance(lat,offset){
	var R = 6378137;

	//convert the offset
	rad_lat_offset = offset/R;
	
	//new coordinates, to degrees
	new_lat = (lat - rad_lat_offset * 180/Math.PI).toFixed(6);
	
	//console.log(parseFloat(new_lat));
	return parseFloat(new_lat);
}

function LngCoordDistance(lat,lng,offset){
	var R = 6378137;

	//convert the offset
	rad_lng_offset =  offset/(R*Math.cos(Math.PI/180*lat));
	
	//new coordinates, to degrees
	new_lng = (lng + rad_lng_offset * 180/Math.PI).toFixed(6);

	//console.log(parseFloat(new_lng));
	return parseFloat(new_lng);
}
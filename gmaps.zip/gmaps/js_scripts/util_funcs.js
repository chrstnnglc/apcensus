function getWDBtxt(){
	var filter_count = 0;
	var filtered_ws_macs = [];
	for(i = 0; i < rectArr.length; i++){
		//only check those rectangle that where traversed
		if(RectinfArr[i].traversal > 0){
			for(x = 0; x < ws_lat.length; x++){
				var point = new google.maps.LatLng(ws_lat[x], ws_lng[x]);
				if(rectArr[i].getBounds().contains(point)){
					filter_count++;
					filtered_ws_macs.push(ws_macs[x]);
				}
			}
		}
	}
	for(i=0; i< filtered_ws_macs.length; i++){
		console.log(filtered_ws_macs[i]);
	}
}

function LatCoordDistance(lat,offset){
	var R = 6378137;

	//convert the offset
	rad_lat_offset = offset/R;
	
	//new coordinates, to degrees
	new_lat = (lat - rad_lat_offset * 180/Math.PI).toFixed(6);
	
	//console.log(parseFloat(new_lat));
	return parseFloat(new_lat);
}

function LngCoordDistance(lat,lng,offset){
	var R = 6378137;

	//convert the offset
	rad_lng_offset =  offset/(R*Math.cos(Math.PI/180*lat));
	
	//new coordinates, to degrees
	new_lng = (lng + rad_lng_offset * 180/Math.PI).toFixed(6);

	//console.log(parseFloat(new_lng));
	return parseFloat(new_lng);
}
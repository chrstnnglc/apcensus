var ws_markers = [];		//this array will contain the markers of Wigle DB APs
var rp_markers = [];		//this array will contain the markers of RPi APs
var w_markers = [];			//this array will contain the markers of Wigle App APs
var c_markers = [];			//this array will contain the markers of Confident RPi APs
var rectArr = [];			//this array will contain the rectangle obj. (rectangles in the map)
var RPmarkerinfArr = [];	//this array will contain the info about the markers of RPi	
var WSmarkerinfArr = [];	//this array will contain the info about the markers of Wigle DB
var WmarkerinfArr = [];		//this array will contain the info about the markers of Wigle App
var CmarkerinfArr = [];		//this array will contain the info about the markers of Confident RPi
var RectinfArr = [];		//this array will contain the info about the rectangles
var GPSmarkerinfArr = [];	//this array will contain the info about the GPS markers

var toMarkArr = [];
var map, rp_count, w_count, ws_count, c_count, rect_count, total_count;
var has_readingsCount = 0;
function RPsetMap(map) {
	for (var i = 0; i < rp_markers.length; i++) {
	  rp_markers[i].setMap(map);
	}
}
function WsetMap(map) {
	for (var i = 0; i < w_markers.length; i++) {
	  w_markers[i].setMap(map);
	}
}
function WSsetMap(map) {
	for (var i = 0; i < ws_markers.length; i++) {
	  ws_markers[i].setMap(map);
	}
}

function redrawRectangle(map){
	for (var i = 0; i < rectArr.length; i++) {
		rectArr[i].setMap(map);
	}
}

function toMarksetMap(map){
	for (var i = 0; i < toMarkArr.length; i++) {
		toMarkArr[i].setMap(map);
	}
}
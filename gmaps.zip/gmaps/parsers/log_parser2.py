##THIS PARSES bflogs.txt files in ROCMAN and uses beacons.txt to match mac with ssid
bf_file = open("../teachersvill/log-24/bflog.txt","r")
beac_file = open("../teachersvill/log-24/beacons.txt","r")
res_file = open("../teachersvill/log-24/parsed_bflog2.txt","w")

unique_aps = []
ap_list = []


class AP:
	def __init__(self, bssid=None, coord=None, rssi=None, channel=None, ssid=None):
		self.bssid = bssid
		self.coord = coord
		self.rssi = rssi
		self.channel = channel
		self.ssid = ssid

beac_mac = []
beac_ssid = []
#create list of mac and its corresponding ssid from the beacons.txt file
for line in beac_file:
        mac = line[:17]
        ssid = line[20:].rstrip()
        beac_mac.append(mac)
        beac_ssid.append(ssid)

#make a unique list of APs with information using the bf_log.txt file    
for line in bf_file:
        parsed = line.split()
        bssid = parsed[3]
        rssi = parsed[5]
        channel = parsed[7]
        coord = parsed[8]
        coord = coord[1:]               #remove the @ symbol

        ##only consider those with gps readings
        if coord != "0.000000,0.000000":
                if bssid not in unique_aps:
                        #find its matching bssid
                        if bssid in beac_mac:
                                ind_match = beac_mac.index(bssid)
                                ssid = beac_ssid[ind_match]
                                if "\00" in ssid or ssid == "":
                                        ssid = "None"
                                else:
                                        ssid = ssid.replace("'", "")
                        else:
                                ssid = "None"
                        
                        new_ap = AP(bssid,coord,rssi,channel,ssid)
			unique_aps.append(bssid)
			ap_list.append(new_ap)
		else:
			for item in ap_list:
				##check if its rssi in this reading is smaller than its current record in ap_list then replace its current rssi and coordinate
				if item.bssid == bssid:
					if int(item.rssi) < int(rssi):
						item.rssi = rssi
						item.coord = coord

##print results
for item in ap_list:
	text = str(item.bssid) + " = " + str(item.coord) + " = " + str(item.rssi) + " = " + str(item.channel) + " | " + str(item.ssid) + "\n"
	res_file.write(text)

bf_file.close()
beac_file.close()
res_file.close()

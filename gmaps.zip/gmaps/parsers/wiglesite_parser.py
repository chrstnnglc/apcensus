import csv
from datetime import datetime

res_file = open("holyspirit/parsed_wiglesite.txt","w")

unique_bssid = []
wigle_list = []

class AP:
	def __init__(self, gps_time=None, time_capt=None, mac=None, ssid=None, coord=None, rssi=None, channel=None, lat=None, lng=None):
                self.ssid = ssid
		self.mac = mac
		self.rssi = rssi
		self.channel = channel

def time_convert(time):
    old_time = datetime.strptime(time, "%Y-%m-%d, %I:%M:%S %p")
    new_time = datetime.strftime(old_time,"%Y-%m-%d %H:%M:%S")
    return str(new_time)

with open('ap_list.csv','rb') as csvfile:
	reader = csv.reader(csvfile, delimiter=',', quotechar='|')
	i = 0
	for row in reader:
		if i > 0:	##ignore first line, what if ignore din lastupd < 2017????
			row = ','.join(row)
			line = row.split(',')

			ssid = line[0]
			ssid = ssid.replace("'", '')
			bssid = line[1]
			channel = "none"
			rssi = "none"
			lat = line[2]
			lng = line[3]
			coord = "%s,%s" %(lat,lng)
			if bssid not in unique_bssid:
				unique_bssid.append(bssid)
				new_ap = AP(ssid,bssid,coord,rssi,channel)
				wigle_list.append(new_ap)
		i += 1
		
for item in wigle_list:
    text = str(item.ssid) + "|" + str(item.bssid) + "|" + str(item.coord) + "|" + str(item.rssi) + "|" + str(item.channel) + "\n"
    res_file.write(text)

res_file.close()

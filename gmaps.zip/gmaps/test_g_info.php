<?php
	$username="root";
	$password="";
	$database="gmaps";
?>